#' Set zeros in dataset to NA.
#'
#' Every 0 value in the dataset is replaced by an NA. Used for platforms that represent missing/sub-LOD values as zeros.
#'
#' @param D \code{SummarizedExperiment} input
#'
#' @return assay: zeros replaced by NA
#'
#' @examples
#' \dontrun{# in the context of a SE pipeline
#' ... %>% mt_pre_zeroToNA() %>% ...
#' }
#'
#' @author JK
#'
#' @importFrom magrittr %>% %<>%
#' @import SummarizedExperiment
#'
#' @export

mt_pre_zeroToNA <- function(
  D      # SummarizedExperiment input
) {

  # validate arguments
  stopifnot("SummarizedExperiment" %in% class(D))

  # replace
  X <- assay(D)
  X[X==0] <- NA
  assay(D) <- X

  # add status information
  funargs <- mti_funargs()
  metadata(D)$results %<>%
    mti_generate_result(
      funargs = funargs,
      logtxt = "zeros replaced by NAs"
    )

  # return
  D

}
