#' Outputs assay, colData and rowData into an Excel file.
#' 
#' Exports the current SummarizedExperiment (not the metadata) to an Excel file.
#'
#' @param D \code{SummarizedExperiment} input
#' @param file output filename to write to
#'
#' @return Does not change the SummarizedExperiment.
#'
#' @examples
#' \dontrun{%>% mt_files_write_xls(file = "out.xlsx") %>%}
#' @author JK, BGP
#' 
#' @importFrom magrittr %>% %<>%
#' @import SummarizedExperiment
#' 
#' @export
mt_files_write_xls <- function(D, file) {
  
  # verify that input is a SummarizedExperiment
  stopifnot("SummarizedExperiment" %in% class(D))
  stopifnot(is.character(file))
  
  # write out
  wb <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb,"assay")
  openxlsx::writeData(wb, "assay", assay(D), rowNames = T, colNames=T)
  openxlsx::addWorksheet(wb,"rowData")
  openxlsx::writeData(wb, "rowData", rowData(D) %>% as.data.frame(), rowNames = T)
  openxlsx::addWorksheet(wb,"colData")
  openxlsx::writeData(wb, "colData", colData(D) %>% as.data.frame())
  openxlsx::saveWorkbook (wb, file=file, overwrite=TRUE) 
  
  # add status information
  funargs <- mti_funargs()
  metadata(D)$results %<>% 
    mti_generate_result(
      funargs = funargs,
      logtxt = sprintf("Data exported to Excel file '%s'", file)
    )
  
  
  # pass SummarizedExperiment back, so pipeline can keep running
  D
  
}
