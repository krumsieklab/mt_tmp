#' Generate p-value qq plot
#'
#' QQ plot against uniform distribution.
#'
#' @param D \code{SummarizedExperiment} input
#' @param comp Name of the statistical result.
#'
#' @return $result: plot, p-value histogram
#'
#' @examples
#' \dontrun{... %>% mt_plots_pvalhist(statnames='comp') %>% ...  # for one
#' }
#'
#' @import ggplot2
#' @importFrom magrittr %>% %<>%
#' @import SummarizedExperiment
#'
#' @author JK

mt_plots_pvalqq <- function(
  D,
  comp
) {

  # validate argument
  stopifnot("SummarizedExperiment" %in% class(D))

  # trick: access argument so that a missing argument error is thrown from here instead of from inside mti_get_stat_by_name
  comp
  # get statistical result
  res <- mti_get_stat_by_name(D, comp)

  # create plot
  p <- mti_gg_qqplot(res$p.value) + ggtitle(sprintf("P-value QQ plot for '%s'", comp))

  # add status information & plot
  funargs <- mti_funargs()
  metadata(D)$results %<>%
    mti_generate_result(
      funargs = funargs,
      logtxt = glue::glue("P-value QQ plot for {paste0(comp, collapse=', ')}"),
      output = p
    )

  # return
  D

}


# Function from https://slowkow.com/notes/ggplot2-qqplot/
#
#' Create a quantile-quantile plot with ggplot2.
#'
#' Assumptions:
#'   - Expected P values are uniformly distributed.
#'   - Confidence intervals assume independence between tests.
#'     We expect deviations past the confidence intervals if the tests are
#'     not independent.
#'     For example, in a genome-wide association study, the genotype at any
#'     position is correlated to nearby positions. Tests of nearby genotypes
#'     will result in similar test statistics.
#'
#' @param ps Vector of p-values.
#' @param ci Size of the confidence interval, 95% by default.
#'
#' @return A ggplot2 plot.
#'
#' @examples
#' \dontrun{mti_gg_qqplot(runif(1e2)) + theme_grey(base_size = 24)
#' }
#'
#' @noRd
mti_gg_qqplot <- function(ps, ci = 0.95) {
  n  <- length(ps)
  df <- data.frame(
    observed = -log10(sort(ps)),
    expected = -log10(ppoints(n)),
    clower   = -log10(qbeta(p = (1 - ci) / 2, shape1 = 1:n, shape2 = n:1)),
    cupper   = -log10(qbeta(p = (1 + ci) / 2, shape1 = 1:n, shape2 = n:1))
  )
  log10Pe <- expression(paste("Expected -log"[10], plain(P)))
  log10Po <- expression(paste("Observed -log"[10], plain(P)))
  ggplot(df) +
    geom_ribbon(
      mapping = aes(x = expected, ymin = clower, ymax = cupper),
      alpha = 0.1
    ) +
    geom_point(aes(expected, observed), shape = 1, size = 3) +
    geom_abline(intercept = 0, slope = 1, alpha = 0.5) +
    # geom_line(aes(expected, cupper), linetype = 2, size = 0.5) +
    # geom_line(aes(expected, clower), linetype = 2, size = 0.5) +
    xlab(log10Pe) +
    ylab(log10Po)
}

